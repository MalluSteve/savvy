# Privacy Policy

## Profile Information
Nadeko stores userids, avatars, usernames, discriminators and nicknames of users who were targeted by or have used commands which require Xp, Clubs or Waifu features (not limited to these, as other features may be added over time).

## Other
Nadeko doesn't do analytics, doesn't store messages, doesn't track users, doesn't store their emails etc.  
Nadeko only stores user settings and states as the result of executed commands or as the effect of administration tools (for example warnings or protection commands).

## Sensitive Information
Nadeko doesn't store sensitive information, and users are strongly discouraged from adding their passwords, keys, or other important information as quotes or expressions.