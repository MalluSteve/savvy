[![nadeko0](https://cdn.nadeko.bot/tutorial/docs-top.png)](https://nadeko.bot/)  
  
[![nadeko1](https://cdn.nadeko.bot/tutorial/docs-mid.png)](https://invite.nadeko.bot/)  
 
[![nadeko2](https://cdn.nadeko.bot/tutorial/docs-bot.png)](https://nadeko.bot/commands)

### Useful links
- [Self hosting Guides and Docs](https://nadekobot.readthedocs.io/en/v4)
- [Discord support server](https://discord.nadeko.bot)
