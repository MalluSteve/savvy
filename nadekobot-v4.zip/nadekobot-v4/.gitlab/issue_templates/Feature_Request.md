GitLab is for bug reports only.  
Please, head over to https://nadeko.bot/suggest to make feature requests.