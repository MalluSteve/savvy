namespace Nadeko.Snake;

/// <summary>
/// Marks the parameter to take 
/// </summary>
[AttributeUsage(AttributeTargets.Parameter)]
public class leftoverAttribute : Attribute
{
    
}