﻿namespace Nadeko.Snake;

[AttributeUsage(AttributeTargets.Method)]
public sealed class bot_owner_onlyAttribute : MedusaPermAttribute
{
    
}