﻿namespace NadekoBot;

public enum EmbedColor
{
    Ok,
    Pending,
    Error
}