﻿namespace Nadeko.Econ;

public enum RegularSuit
{
    Hearts,
    Diamonds,
    Clubs,
    Spades
}