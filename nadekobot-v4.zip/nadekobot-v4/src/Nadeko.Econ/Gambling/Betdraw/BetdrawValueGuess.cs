﻿namespace Nadeko.Econ.Gambling.Betdraw;

public enum BetdrawValueGuess
{
    High,
    Low,
}