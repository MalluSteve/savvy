﻿namespace Nadeko.Econ.Gambling.Betdraw;

public enum BetdrawResultType
{
    Win,
    Lose
}