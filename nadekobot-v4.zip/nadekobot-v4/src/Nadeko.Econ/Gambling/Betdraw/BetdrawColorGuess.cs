﻿namespace Nadeko.Econ.Gambling.Betdraw;

public enum BetdrawColorGuess
{
    Red,
    Black
}