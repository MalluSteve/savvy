#nullable disable
namespace NadekoBot.Common;

public enum AddRemove
{
    Add = int.MinValue,
    Remove = int.MinValue + 1,
    Rem = int.MinValue + 1,
    Rm = int.MinValue + 1
}