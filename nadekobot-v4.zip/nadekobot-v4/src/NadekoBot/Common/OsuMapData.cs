﻿#nullable disable
namespace NadekoBot.Common;

public class OsuMapData
{
    public string Title { get; set; }
    public string Artist { get; set; }
    public string Version { get; set; }
}