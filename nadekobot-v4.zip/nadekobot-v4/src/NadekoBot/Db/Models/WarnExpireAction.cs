#nullable disable
namespace NadekoBot.Services.Database.Models;

public enum WarnExpireAction
{
    Clear,
    Delete
}