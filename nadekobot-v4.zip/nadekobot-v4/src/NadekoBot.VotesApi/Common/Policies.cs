﻿namespace NadekoBot.VotesApi
{
    public static class Policies
    {
        public const string DiscordsAuth = "DiscordsAuth";
        public const string TopggAuth = "TopggAuth";
    }
}